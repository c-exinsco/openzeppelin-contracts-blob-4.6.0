---
name: Feature request
about: Suggest an idea for OpenZeppelin Contracts

---

**🧐 Motivation**
<!-- Is your feature request related to a specific problem? Is it just a crazy idea? Tell us about it! -->

**📝 Details**
<!-- Please describe your feature request in detail. -->

<!-- Make sure that you have reviewed the OpenZeppelin Contracts Contributor Guidelines. -->
<!-- https://github.com/OpenZeppelin/openzeppelin-contracts/blob/master/CONTRIBUTING.md -->
